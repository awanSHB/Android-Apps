package com.example.temp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private Button ctf, ftc;
    private TextView out;
    private EditText temp;
    double O;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ctf =(Button) findViewById(R.id.ctf);
        ftc = (Button) findViewById(R.id.ftc);
        temp = (EditText) findViewById(R.id.temp);
        out = (TextView) findViewById(R.id.out);

        ctf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double T = Double.parseDouble(temp.getText().toString());
                O = (T*1.8) + 32;
                out.setText(String.valueOf(O));

            }
        });
        ftc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double T = Double.parseDouble(temp.getText().toString());
                O = (T-32) / 32;
                out.setText(String.valueOf(O));
            }
        });

    }
}