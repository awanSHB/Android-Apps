package com.example.tictactoe;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private TextView btn0, btn1,btn2, btn3, btn4, btn5, btn6, btn7, btn8;
    private TextView tic;

    int [] gamestate = {2, 2, 2, 2, 2, 2, 2, 2, 2};

    int[][] winningpos = {
            {0, 1, 2},{3, 4, 5},{6, 7, 8},
            {0, 4, 8},{2, 4, 6},{0, 3, 6},
            {1, 4, 7},{2, 5, 8}
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}