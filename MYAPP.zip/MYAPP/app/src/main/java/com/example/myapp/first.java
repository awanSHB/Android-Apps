package com.example.myapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class first extends AppCompatActivity {
    private Button but;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first);

        but = (Button) findViewById(R.id.but);
        but.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(first.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }

    public static class MainActivity extends AppCompatActivity {
        private Button login;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);

            TextView username = (TextView) findViewById(R.id.username);
            TextView Password = (TextView) findViewById(R.id.Password);
            Button login = (Button) findViewById(R.id.login);

            login.setOnClickListener(new  View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (username.getText().toString().equals("Sohaib") && Password.getText().toString().equals("awan")){
                        Intent intent = new Intent(MainActivity.this, Activity2.class);
                        startActivity(intent);
                    }else
                        Toast.makeText(MainActivity.this,"LOGIN FAILED !!!",Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
}