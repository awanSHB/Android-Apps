package com.example.digit;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity2 extends AppCompatActivity {
    private Button sq, cu, fo, fac, st, cub, rad, deg;
    private EditText num, res;
    double a, b, d, r;
    double c = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        sq = (Button) findViewById(R.id.sq);
        cu = (Button) findViewById(R.id.cu);
        fo = (Button) findViewById(R.id.fo);
        fac = (Button) findViewById(R.id.fac);
        st = (Button) findViewById(R.id.st);
        cub = (Button) findViewById(R.id.cub);
        rad = (Button) findViewById(R.id.rad);
        deg = (Button) findViewById(R.id.deg);

        num = (EditText) findViewById(R.id.num);
        res = (EditText) findViewById(R.id.res);

        sq.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                a = Double.parseDouble(num.getText().toString());
                b = a*a;
                res.setText(String.valueOf(b));
            }
        });
        cu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                a = Double.parseDouble(num.getText().toString());
                b = a*a*a;
                res.setText(String.valueOf(b));
            }
        });
        fo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                a = Double.parseDouble(num.getText().toString());
                b = a*a*a*a;
                res.setText(String.valueOf(b));
            }
        });
        fac.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                a = Double.parseDouble(num.getText().toString());
                b = 1;
                while (b<=a){
                    c = c*b;
                    b = b+1;
                }
                res.setText(String.valueOf(c));
            }
        });
        st.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                a = Double.parseDouble(num.getText().toString());
                b = Math.sqrt(a);
                res.setText(String.format("%.4f", b));
            }
        });
        cub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                a = Double.parseDouble(num.getText().toString());
                b = Math.cbrt(a);
                res.setText(String.format("%.4f", b));
            }
        });
        rad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                a = Double.parseDouble(num.getText().toString());
                b = a*0.0174;
                res.setText(String.format("%.2f rad",b));
            }
        });
        deg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                a = Double.parseDouble(num.getText().toString());
                b = a*57.2956;
                res.setText(String.format("%.2f deg", b));
            }
        });
    }
}