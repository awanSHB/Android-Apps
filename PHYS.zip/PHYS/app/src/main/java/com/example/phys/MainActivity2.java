package com.example.phys;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {
    private Button bt,  log;
    private EditText b, c;
    private TextView pt;
    double speed, distance, time, str;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        bt = (Button) findViewById(R.id.bt);
        log = (Button) findViewById(R.id.log);
        b = (EditText) findViewById(R.id.b);
        c = (EditText) findViewById(R.id.c);
        pt = (TextView) findViewById(R.id.pt);

        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                distance = Double.parseDouble(b.getText().toString());
                time = Double.parseDouble(c.getText().toString());
                speed = distance/time;
                pt.setText(String.format("%.2fkm/s", speed));

            }
        });
        log.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity2.this, MainActivity.class);
                startActivity(intent);
            }
        });

    }
}