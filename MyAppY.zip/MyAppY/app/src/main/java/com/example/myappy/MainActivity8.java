package com.example.myappy;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity8 extends AppCompatActivity {
    private Button dtp, ptd, etp, ytp, ktp, pti, log;
    private EditText am, res;
    double a, b, c, d;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main8);

        dtp = (Button) findViewById(R.id.dtp);
        ptd = (Button) findViewById(R.id.ptd);
        etp = (Button) findViewById(R.id.etp);
        ytp = (Button) findViewById(R.id.ytp);
        ktp = (Button) findViewById(R.id.ktp);
        pti = (Button) findViewById(R.id.pti);
        log = (Button) findViewById(R.id.log);

        am = (EditText) findViewById(R.id.am);
        res = (EditText) findViewById(R.id.res);

        dtp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                a = Double.parseDouble(am.getText().toString());
                b = a*178.70;
                res.setText(String.format("%.2f", b));

            }
        });
        ptd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                a = Double.parseDouble(am.getText().toString());
                b = a/178.70;
                res.setText(String.format("%.2f", b));
            }
        });
        etp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                a = Double.parseDouble(am.getText().toString());
                b = a*195.00;
                res.setText(String.format("%.2f", b));
            }
        });
        ytp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                a = Double.parseDouble(am.getText().toString());
                b = a*28.19;
                res.setText(String.format("%.2f", b));
            }
        });
        ktp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                a = Double.parseDouble(am.getText().toString());
                b = a*588.02;
                res.setText(String.format("%.2f", b));
            }
        });
        pti.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                a = Double.parseDouble(am.getText().toString());
                b = a*236.71;
                res.setText(String.format("%.2f", b));
            }
        });
        log.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity8.this, MainActivity4.class);
                startActivity(intent);
            }
        });
    }
}