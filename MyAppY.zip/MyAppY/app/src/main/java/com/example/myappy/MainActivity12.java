package com.example.myappy;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity12 extends AppCompatActivity {
    private Button bt,  log;
    private EditText b, c;
    private TextView pt;
    double speed, distance, time, st;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main12);
        bt = (Button) findViewById(R.id.bt);
        log = (Button) findViewById(R.id.log);
        b = (EditText) findViewById(R.id.b);
        c = (EditText) findViewById(R.id.c);
        pt = (TextView) findViewById(R.id.pt);

        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                distance = Double.parseDouble(b.getText().toString());
                speed = Double.parseDouble(c.getText().toString());
                time = distance/speed;
                st = time*60;
                pt.setText(String.format("%.2f MIN", st));

            }
        });
        log.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity12.this, MainActivity9.class);
                startActivity(intent);
            }
        });

    }
}