package com.example.myappy;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity5 extends AppCompatActivity {
    private Button ctf, ftc, log;
    private TextView out;
    private EditText temp;
    double O;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);

        ctf =(Button) findViewById(R.id.ctf);
        ftc = (Button) findViewById(R.id.ftc);
        temp = (EditText) findViewById(R.id.temp);
        out = (TextView) findViewById(R.id.out);
        log = (Button) findViewById(R.id.log);

        ctf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double T = Double.parseDouble(temp.getText().toString());
                O = (T*1.8) + 32;
                out.setText(String.valueOf(O));

            }
        });
        ftc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double T = Double.parseDouble(temp.getText().toString());
                O = (T-32) / 32;
                out.setText(String.valueOf(O));

            }
        });
        log.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity5.this, MainActivity4.class);
                startActivity(intent);
            }
        });

    }
}