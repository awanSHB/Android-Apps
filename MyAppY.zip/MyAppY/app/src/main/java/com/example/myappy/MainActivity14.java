package com.example.myappy;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity14 extends AppCompatActivity {
    private Button bt,  log;
    private EditText b, c;
    private TextView pt;
    double force, area, pressure;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main14);
        bt = (Button) findViewById(R.id.bt);
        log = (Button) findViewById(R.id.log);
        b = (EditText) findViewById(R.id.b);
        c = (EditText) findViewById(R.id.c);
        pt = (TextView) findViewById(R.id.pt);

        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                force = Double.parseDouble(b.getText().toString());
                area = Double.parseDouble(c.getText().toString());
                pressure = force/area;
                pt.setText(String.format("%.2fpasc.", pressure));

            }
        });
        log.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity14.this, MainActivity9.class);
                startActivity(intent);
            }
        });

    }
}